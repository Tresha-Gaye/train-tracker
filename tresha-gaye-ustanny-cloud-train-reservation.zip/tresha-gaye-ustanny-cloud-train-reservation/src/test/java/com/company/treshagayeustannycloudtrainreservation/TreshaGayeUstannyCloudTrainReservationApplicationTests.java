package com.company.treshagayeustannycloudtrainreservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreshaGayeUstannyCloudTrainReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
