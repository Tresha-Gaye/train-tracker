package com.company.treshagayeustannycloudconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreshaGayeUstannyCloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
